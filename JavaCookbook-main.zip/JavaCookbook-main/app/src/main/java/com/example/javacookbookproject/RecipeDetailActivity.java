// RecipeDetailActivity.java
package com.example.javacookbookproject;

        import android.os.Bundle;
        import androidx.appcompat.app.AppCompatActivity;

public class RecipeDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail); // Replace with your actual layout
        // You can customize this activity to display the details of the selected recipe
    }
}
